Ce challenge doit être effectué sur votre conteneur, sur lequel a été installé
un programme mystère. 

Le répertoire sandbox/ contient de nombreux fichiers, de sorte qu'il utilise
7,6MiB sur le disque :

    $ du -sh sandbox/
    7,6M	sandbox

De nombreux fichiers ont le même contenu. Faites en sorte que l'arborescence
reste inchangée en termes de contenu des noms de fichiers, mais que la place du
répertoire sandbox/ dans le système de fichiers soit inférieur à 400KiB.

