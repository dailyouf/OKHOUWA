Faites en sorte que le fichier nommé ./sandbox/dangereux disparaisse de son
système de fichiers (et lui seul).
