public enum Direction {
    NORD, EST, SUD, OUEST
}
